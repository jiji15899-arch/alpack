<?php
/**
 * PressLearn API - 누구나 사용 가능 (메인 파일 수정 없이)
 */

if (!defined('ABSPATH')) {
    exit;
}

class PressLearn_API {
 
    public static function init() {
        add_action('rest_api_init', array(__CLASS__, 'register_endpoints'));
        add_action('rest_api_init', array(__CLASS__, 'add_cors_support'));
        add_filter('rest_authentication_errors', array(__CLASS__, 'disable_rest_authentication'), 999);
        add_filter('rest_nonce_enabled', array(__CLASS__, 'disable_nonce_for_presslearn'), 999);
        add_action('rest_api_init', array(__CLASS__, 'remove_cookie_check_for_presslearn'));
        
        // 플러그인 로드 시 자동 활성화 체크
        add_action('plugins_loaded', array(__CLASS__, 'ensure_activation'), 1);
    }
    
    /**
     * 플러그인이 항상 활성화 상태인지 확인
     */
    public static function ensure_activation() {
        $key = get_option('presslearn_plugin_key', '');
        
        // 키가 없으면 자동 생성
        if (empty($key)) {
            $auto_key = 'ALPACK_AUTO_' . wp_generate_password(32, false);
            update_option('presslearn_plugin_key', $auto_key);
            update_option('presslearn_plugin_activated_time', time());
            
            error_log('AL Pack: Auto-activated on plugin load');
        }
    }
    
    public static function disable_rest_authentication($errors) {
        $current_route = isset($_SERVER['REQUEST_URI']) ? sanitize_text_field(wp_unslash($_SERVER['REQUEST_URI'])) : '';
        
        if (strpos($current_route, '/wp-json/presslearn/') !== false) {
            return true;
        }
        
        return $errors;
    }
    
    public static function disable_nonce_for_presslearn($enabled) {
        $current_route = isset($_SERVER['REQUEST_URI']) ? sanitize_text_field(wp_unslash($_SERVER['REQUEST_URI'])) : '';
        
        if (strpos($current_route, '/wp-json/presslearn/') !== false) {
            return false;
        }
        
        return $enabled;
    }
    
    public static function remove_cookie_check_for_presslearn() {
        add_filter('rest_pre_dispatch', function($result, $server, $request) {
            $route = $request->get_route();
            
            if (strpos($route, '/presslearn/') === 0) {
                remove_filter('rest_pre_dispatch', 'rest_cookie_check_errors', 10);
            }
            
            return $result;
        }, 5, 3);
    }
    
    public static function add_cors_support() {
        add_filter('rest_pre_serve_request', function($served, $result, $request) {
            $route = $request->get_route();
            
            if (strpos($route, '/presslearn/') === 0) {
                $origin = get_http_origin();
                if ($origin) {
                    header('Access-Control-Allow-Origin: ' . esc_url_raw($origin));
                    header('Access-Control-Allow-Methods: POST, GET, OPTIONS');
                    header('Access-Control-Allow-Headers: Content-Type, Authorization');
                    header('Access-Control-Allow-Credentials: true');
                }
                
                if (isset($_SERVER['REQUEST_METHOD']) && sanitize_text_field(wp_unslash($_SERVER['REQUEST_METHOD'])) === 'OPTIONS') {
                    status_header(200);
                    return true;
                }
            }
            
            return $served;
        }, 10, 3);
    }

    public static function register_endpoints() {
        register_rest_route('presslearn/v1', '/activate', array(
            'methods' => 'POST',
            'callback' => array(__CLASS__, 'activate_plugin'),
            'permission_callback' => '__return_true',
        ));
        
        register_rest_route('presslearn/v1', '/status', array(
            'methods' => 'GET',
            'callback' => array(__CLASS__, 'check_status'),
            'permission_callback' => '__return_true',
        ));

        register_rest_route('presslearn/v1', '/banner', array(
            'methods' => 'GET',
            'callback' => array(__CLASS__, 'get_banner'),
            'permission_callback' => '__return_true',
        ));
        
        register_rest_route('presslearn/v1', '/notice', array(
            'methods' => 'GET',
            'callback' => array(__CLASS__, 'get_latest_notice'),
            'permission_callback' => '__return_true',
        ));
    }

    public static function activate_plugin($request) {
        // 자동 활성화 키 생성 (키 검증 없이 항상 성공)
        $auto_key = 'ALPACK_AUTO_' . wp_generate_password(32, false);
        
        update_option('presslearn_plugin_key', $auto_key);
        update_option('presslearn_plugin_activated_time', time());
        
        self::log_activation_event($auto_key);
        
        return array(
            'success' => true,
            'message' => 'AL Pack 플러그인이 활성화되었습니다.',
            'timestamp' => current_time('timestamp'),
        );
    }
    
    public static function check_status($request) {
        $key = get_option('presslearn_plugin_key', '');
        
        // 키가 없으면 자동 생성
        if (empty($key)) {
            $auto_key = 'ALPACK_AUTO_' . wp_generate_password(32, false);
            update_option('presslearn_plugin_key', $auto_key);
            update_option('presslearn_plugin_activated_time', time());
        }
        
        $activated_time = get_option('presslearn_plugin_activated_time', 0);
        
        return array(
            'is_active' => true, // 항상 활성화 상태
            'activated_time' => $activated_time,
            'message' => 'AL Pack 플러그인이 활성화되어 있습니다.'
        );
    }

    private static function log_activation_event($key) {
        $masked_key = substr($key, 0, 8) . '...' . substr($key, -8);
        
        $remote_addr = isset($_SERVER['REMOTE_ADDR']) ? sanitize_text_field(wp_unslash($_SERVER['REMOTE_ADDR'])) : '';
        $user_agent = isset($_SERVER['HTTP_USER_AGENT']) ? sanitize_text_field(wp_unslash($_SERVER['HTTP_USER_AGENT'])) : '';
        $origin = get_http_origin();
        
        $user_info = 'anonymous';
        if (is_user_logged_in()) {
            $current_user = wp_get_current_user();
            $user_info = $current_user->user_login . ' (ID: ' . $current_user->ID . ')';
        }
        
        $log_data = array(
            'time' => current_time('mysql'),
            'key' => $masked_key,
            'ip' => $remote_addr,
            'user_agent' => $user_agent,
            'origin' => $origin,
            'user' => $user_info,
            'is_admin' => current_user_can('manage_options'),
            'method' => 'AUTO_ACTIVATION'
        );
        
        $activation_logs = get_option('presslearn_activation_logs', array());
        $activation_logs[] = $log_data;
        
        if (count($activation_logs) > 20) {
            $activation_logs = array_slice($activation_logs, -20);
        }
        
        update_option('presslearn_activation_logs', $activation_logs);
        
        error_log('AL Pack Auto Activation: ' . json_encode($log_data));
    }

    public static function get_banner($request) {
        $supabase_url = 'https://odkponsvhcfajgoetubm.supabase.co';
        $supabase_key = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Im9ka3BvbnN2aGNmYWpnb2V0dWJtIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NDU4OTIxMjMsImV4cCI6MjA2MTQ2ODEyM30.yR08gaJeSy4kagAT3PZl1i8uAC6aEEnZSfQ4sSbqOYk';
        
        $response = wp_remote_get(
            $supabase_url . '/rest/v1/banner_table?id=eq.1',
            array(
                'headers' => array(
                    'apikey' => $supabase_key,
                    'Authorization' => 'Bearer ' . $supabase_key,
                    'Content-Type' => 'application/json'
                )
            )
        );

        if (is_wp_error($response)) {
            return new WP_Error(
                'banner_fetch_error',
                '배너 데이터를 가져오는데 실패했습니다.',
                array('status' => 500)
            );
        }

        $body = wp_remote_retrieve_body($response);
        $data = json_decode($body, true);

        if (empty($data)) {
            return new WP_Error(
                'no_banner',
                '배너 데이터가 없습니다.',
                array('status' => 404)
            );
        }

        return array(
            'success' => true,
            'data' => $data[0]
        );
    }
    
    public static function get_latest_notice($request) {
        $cache_key = 'presslearn_latest_notice';
        $cached_notice = get_transient($cache_key);
        
        if ($cached_notice !== false) {
            return array(
                'success' => true,
                'data' => $cached_notice
            );
        }
        
        $feed_url = 'https://alpack.dev/category/notice/feed/';
        
        $response = wp_remote_get($feed_url, array(
            'timeout' => 10,
            'user-agent' => 'AL Pack Plugin/' . get_bloginfo('url'),
            'sslverify' => true
        ));
        
        if (is_wp_error($response)) {
            error_log('AL Pack Notice Feed Error: ' . $response->get_error_message());
            return new WP_Error(
                'notice_fetch_error',
                '공지사항을 가져오는데 실패했습니다.',
                array('status' => 500)
            );
        }
        
        $body = wp_remote_retrieve_body($response);
        
        $xml = simplexml_load_string($body, 'SimpleXMLElement', LIBXML_NOCDATA);
        
        if ($xml === false) {
            return new WP_Error(
                'notice_parse_error',
                '공지사항 데이터 파싱에 실패했습니다.',
                array('status' => 500)
            );
        }
        
        $latest_notice = array();
        if (isset($xml->channel->item[0])) {
            $item = $xml->channel->item[0];
            $latest_notice = array(
                'title' => (string) $item->title,
                'link' => (string) $item->link,
                'date' => date('Y-m-d', strtotime((string) $item->pubDate))
            );
            
            set_transient($cache_key, $latest_notice, DAY_IN_SECONDS);
        }
        
        if (empty($latest_notice)) {
            return new WP_Error(
                'no_notice',
                '공지사항이 없습니다.',
                array('status' => 404)
            );
        }
        
        return array(
            'success' => true,
            'data' => $latest_notice
        );
    }
}

PressLearn_API::init();